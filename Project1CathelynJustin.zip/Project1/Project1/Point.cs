﻿/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Project:          Project1
// File Name:        Point.cs
// Description:      Manages the ussage of points on the UPS route
// Course:           CSCI 3230-001 - Algorithms
// Author:           Justin Cathelyn, cathelynj@etsu.edu
// Created:          Thursday, August 30, 2018
// Copyright:        Cathelyn, 2018
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
    /// <summary>
    /// Manages the ussage of points on the UPS route
    /// </summary>
    class Point
    {
        #region Properties
        /// <summary>
        /// Gets and sets the X coordinate
        /// </summary>
        public int X { get; set; }//the X coordinate of a 
        /// <summary>
        /// Gets and sets the Y coordinate
        /// </summary>
        public int Y { get; set; }//the Y coordinate of a point
        #endregion

        #region Constructors
        /// <summary>
        /// Default constructor
        /// </summary>
        public Point()
        {
            this.X = 0;
            this.Y = 0;
        }

        /// <summary>
        /// Creates a new point
        /// </summary>
        /// <param name="XCoord"></param>
        /// <param name="YCoord"></param>
        public Point(int XCoord, int YCoord)
        {
            this.X = XCoord;
            this.Y = YCoord;
        }

        /// <summary>
        /// Copy Constructor
        /// </summary>
        /// <param name="point"></param>
        public Point(Point point)
        {
            this.X = point.X;
            this.Y = point.Y;
        }
        #endregion

        #region FindDistance
        /// <summary>
        /// Calculates the distance between points
        /// </summary>
        /// <param name="point1"></param>
        /// <param name="point2"></param>
        /// <returns></returns>
        public static double FindDistance(Point pointA, Point pointB)
        {
            return Math.Sqrt(Math.Pow(pointB.X - pointA.X, 2) + Math.Pow(pointB.Y - pointA.Y, 2));
        }
        #endregion

        #region ToString
        /// <summary>
        /// Returns the points X and Y coordinates as a string
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return X + " " + Y;
        }
        #endregion
    }
}
