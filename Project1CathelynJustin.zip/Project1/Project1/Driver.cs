﻿/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Project:          Project1
// File Name:        Driver.cs
// Description:      Finds the shortest route between a set of points
// Course:           CSCI 3230-001 - Algorithms
// Author:           Justin Cathelyn, cathelynj@etsu.edu
// Created:          Thursday, August 30, 2018
// Copyright:        Cathelyn, 2018
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Project1
{
    /// <summary>
    /// Finds the shortest route between a set of points
    /// </summary>
    class Driver
    {
        public static Point[] PointArray;//array of all the points on the grid
        public static double[,] Distances;//holds all the distances between points
        public static double ShortestDist = double.MaxValue;//sets the shortest distance to the maximum possible value;//shortest distance between points
        public static int[] OptimalRoute;//optimal route between points
        /// <summary>
        /// Finds the shortest route between a set of points
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            int NumPoints;//number of points
            List<Point> PointList = new List<Point>();//list of points on the grid
            int[] perms;//indexes of the points as integers

            #region GetPoints
            Console.WriteLine("Please enter the number of points");
            NumPoints = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Please enter your points");
            for (int i = 0; i < NumPoints; i++)
            {
                string coordinate = Console.ReadLine();//points entered as a string
                string[] coordinates = coordinate.Split(' ');//split the string into X and Y

                //Make a new point from the X and Y
                Point point = new Point(Convert.ToInt32(coordinates[0]), Convert.ToInt32(coordinates[1]));
                PointList.Add(point);
            }
            #endregion

            PointArray = PointList.ToArray();//convert list to array
            OptimalRoute = new int[PointArray.Length];
            Distances = new double[PointArray.Length, PointArray.Length];
            perms = new int[PointArray.Length];
            for (int i = 0; i < PointArray.Length; i++)//creates a list of indexes from 0 to NumPoints
            {
                perms[i] = i;
            }
            
            Console.WriteLine("Calculating...");

            Stopwatch sw = Stopwatch.StartNew();
            
            MakeTable();//calculates all the distances between points
            FindQuickestRoute(perms, 0, perms.Length - 1);//get the quickest route

            //tacks on the distance from the origin at beggining and end of route
            
            sw.Stop();
            Console.WriteLine(sw.Elapsed.TotalMilliseconds / 1000);

            Console.WriteLine("Shortest Distance: " + ShortestDist);
            Console.Write("Optimal Route: 0 ");
            for (int i = 0; i < OptimalRoute.Length; i++)
            {
                Console.Write((OptimalRoute[i] + 1) + " ");
            }


            Console.ReadKey();
        }

        #region Switch
        /// <summary>
        /// Switches two items in the array
        /// </summary>
        /// <param name="pointA"></param>
        /// <param name="pointB"></param>
        public static int[] Switch(int[] pts, int pointA, int pointB)
        {
            int temp = pts[pointA];
            pts[pointA] = pts[pointB];
            pts[pointB] = temp;
            return pts;
        }
        #endregion

        #region FindQuickestRoute
        /// <summary>
        /// Gets the quickest route between a set of points
        /// </summary>
        /// <param name="points"></param>
        /// <param name="start"></param>
        /// <param name="end"></param>
        public static void FindQuickestRoute(int[] points, int start, int end)
        {
            double CurrentDist = 0;//current distance we are looking 

            //when we find a permutation that starts at the origin
            if (end == start && points[0] < points[points.Length - 1])
            {
                CurrentDist += Point.FindDistance(new Point(0, 0), PointArray[points[0]]);
                for (int i = 0; i < points.Length - 1; i++)//calculate distance
                {
                    CurrentDist += Distances[points[i], points[i + 1]];
                }
                CurrentDist += Point.FindDistance(PointArray[points[points.Length - 1]], new Point(0, 0));

                //if the current distance is shorter than the shortest know distance
                if (CurrentDist < ShortestDist)
                {
                    ShortestDist = CurrentDist;
                    for (int i = 0; i < OptimalRoute.Length; i++)
                    {
                        OptimalRoute[i] = points[i];
                    }
                }
            }
            else
            {
                for(int i = end; i >= start; i--)
                {
                    Switch(points, end, i);//switch two points to create a unique permuataion
                    FindQuickestRoute(points, 0, end - 1);//derrive a new permutation from the current unique permuataion
                    Switch(points, end, i);
                }
            }
        }
        #endregion

        #region MakeTable
        /// <summary>
        /// Makes a table of all the distances between points
        /// </summary>
        public static void MakeTable()
        {
            for(int i = 0; i < Distances.GetLength(0); i++)
            {
                for(int j = 0; j < Distances.GetLength(1); j++)
                {
                    Distances[i, j] = Point.FindDistance(PointArray[i], PointArray[j]);
                }
            }
        }
        #endregion
        
    }
}
